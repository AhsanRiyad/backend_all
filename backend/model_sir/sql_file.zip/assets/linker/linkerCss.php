
<!DOCTYPE html>
<html>
<head>
	<title>
		<?php echo $pageName ;  ?>
	</title>
	<link rel="shortcut icon" href="<?php echo $fev_icon ;  ?>" />
	<link rel="stylesheet" href="<?= $bootstrap_grid ?>">
	<link rel="stylesheet" href="<?= $bootstrap_reboot ?>">
	<link rel="stylesheet" href="<?= $bootstrap ?>">
	<link rel="stylesheet" href="<?= $jquery_ui_structure ?>">
	<link rel="stylesheet" href="<?= $jquery_ui_theme ?>">
	

	<!-- materials icon -->
	<link href="https://cdn.jsdelivr.net/npm/@mdi/font@3.x/css/materialdesignicons.min.css" rel="stylesheet">
	<!-- vuetify 2.1.9 -->
	<link href="https://cdn.jsdelivr.net/npm/vuetify@2.x/dist/vuetify.min.css" rel="stylesheet">



	<?php 
	include $APP_ROOT."assets/css/style.php";
	?>

</head>
<body>













